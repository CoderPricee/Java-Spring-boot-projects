package com.chilly.basicspringrestapi.models;

import lombok.Data;

@Data
public class NewUserDto {
    String email;
    String Password;
}
